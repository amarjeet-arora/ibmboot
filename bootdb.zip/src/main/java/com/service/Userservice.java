package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.User;
import com.repo.UserRepo;

@Service
public class Userservice {
	
	
	@Autowired
	private UserRepo userRepo;
	
	private ArrayList<User> al= new ArrayList<>();
	
	public boolean loginValid(String name,String pass) {
		
		
		if(name.equals("admin") && pass.equals("manager")) {
			
			return true;
		}
		
		return false;
	}
	
	public boolean addUser(String name,String email,String pass,String city) {
		
		//al.add(new User(name, email, pass, city));
		userRepo.save(new User(name, email, pass, city));
		
		System.out.println(al);
		return true;
		
		
	}
	public List<User> loadUsers(){
		return al;
	}
	
	
	public boolean findUser(String user) {
		for(User usr:al) {
			if(usr.getName().equals(user)) {
				System.out.println("user found");
				
			}
			return true;
		}
		return false;
		
	}
	
	
	public boolean deleteUser(String user) {
		
		for(User usr:al) {
			if(usr.getName().equals(user)) {
				System.out.println("user found");
				al.remove(usr);
				System.out.println("user deleted");
				return true;
			}
			
		}
		return false;
		
		
	}
	
	
	

}
