package com.example.springbootibmweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootibmwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
