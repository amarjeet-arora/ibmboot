package com.example.springbootibmweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
public class SpringbootibmwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootibmwebApplication.class, args);
	}

}
