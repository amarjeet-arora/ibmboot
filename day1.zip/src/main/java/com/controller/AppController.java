package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.service.Userservice;

@RestController
@RequestMapping("/app")
public class AppController {
	
	@Autowired
	private Userservice userService;
	
	
	 
	@PostMapping("/login")
	public String loginValid(@RequestParam("uname")String name,@RequestParam("pwd")String pass) {
		
		if(userService.loginValid(name, pass)) {
			return " user is validated";
		}
		return " invalid user";
	}
	
 
@PostMapping("/registration")
public String registrationUser(@RequestParam("uname")String name,@RequestParam("pwd")String pass,@RequestParam("email")String email,@RequestParam("city")String city) {
		
		if(userService.addUser(name, email, pass, city)) {
			return " user is added";
		}
		return " user can not be added";
}}
