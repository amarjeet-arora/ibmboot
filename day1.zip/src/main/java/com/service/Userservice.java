package com.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.model.User;

@Service
public class Userservice {
	
	private ArrayList<User> al= new ArrayList<>();
	
	public boolean loginValid(String name,String pass) {
		
		
		if(name.equals("admin") && pass.equals("manager")) {
			
			return true;
		}
		
		return false;
	}
	
	public boolean addUser(String name,String email,String pass,String city) {
		
		al.add(new User(name, email, pass, city));
		
		System.out.println(al);
		return true;
		
		
	}

}
