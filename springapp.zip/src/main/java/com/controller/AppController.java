package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.service.UserService;

//@Controller

@RestController
public class AppController {
	
	
	@Autowired
	private UserService userService;

	@GetMapping("/welcome")

	public String welcome() {
		return "welcome to my application";
	}

	@PostMapping("/login")

	public String loginValid(@RequestParam("uname") String name, @RequestParam("pass") String pass) {
	
		if(userService.loginValidate(name, pass)) {
			
	
			return "login successfull";
		}

		return "login failed";
	}

}
