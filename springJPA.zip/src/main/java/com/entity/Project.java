package com.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.boot.autoconfigure.domain.EntityScan;

@Entity
public class Project {
	
	
	@Id
	private int proId;
	private String projectName;
	private String projectLocation;
	public Project(int proId, String projectName, String projectLocation) {
		super();
		this.proId = proId;
		this.projectName = projectName;
		this.projectLocation = projectLocation;
	}
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}

}
