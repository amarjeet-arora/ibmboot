package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MyRepo;
import com.entity.Project;

@Service
public class ProjectService {
	
	
	@Autowired
	private MyRepo myRepo;
	
	
	public void addProject(Project pro) {
		
		myRepo.save(pro);
		
	}

}
