package com.example.photoappallusers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoappallusersApplicationTests {

	@Test
	void contextLoads() {
	}

}
