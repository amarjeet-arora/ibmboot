package com.ibm.boot.IBMSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com")
public class IbmSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbmSpringBootApplication.class, args);
	}

}
